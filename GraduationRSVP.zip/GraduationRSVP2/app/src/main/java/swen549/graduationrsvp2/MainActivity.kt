package swen549.graduationrsvp2

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import swen549.graduationrsvp2.ui.theme.GraduationRSVP2Theme

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GraduationRSVP2Theme {
                val context = LocalContext.current
                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = { Text("Graduation RSVP-RIT", maxLines = 1) },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                titleContentColor = MaterialTheme.colorScheme.primary
                            )
                        )
                    },
                    floatingActionButton = {
                        FloatingActionButton( onClick = {
                            Toast.makeText(context, "FAB Clicked", Toast.LENGTH_SHORT).show()
                        }) {
                            Icon(Icons.Default.Add, contentDescription = "Add icon")
                        }
                    },
                    modifier = Modifier.fillMaxSize()) { innerPadding ->
                    GradScreen(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun GradScreen(modifier: Modifier = Modifier) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "Graduation Announcement!",
            fontSize = 50.sp,
            lineHeight = 55.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            color = androidx.compose.ui.graphics.Color(255, 125, 125),
            modifier = modifier
        )
        Image(
            painter = painterResource(R.drawable.grad_cap),
            contentDescription = "Graduation cap",
            alignment = Alignment.Center,
            alpha = 0.8f,
            modifier = Modifier.size(250.dp, 250.dp)
        )
        Row() {
            Image(
                painter = painterResource(R.drawable.blue_info),
                contentDescription = "Blue Info icon",
                alignment = Alignment.Center,
                modifier = modifier.alpha(0.8f)
            )
            Text(
                text = "Monday 10am, Golisano Hall 4000",
                fontSize = 20.sp,
                lineHeight = 20.sp,
                maxLines = 1,
                textAlign = TextAlign.Center,
                color = androidx.compose.ui.graphics.Color(125, 125, 255),
                modifier = modifier
            )
        }

        RSVP(modifier = modifier)
    }
}

@Preview(showBackground = true)
@Composable
fun GradScreenPreview() {
    GraduationRSVP2Theme {
        GradScreen()
    }
}

@Preview
@Composable
fun RSVP(modifier: Modifier = Modifier) {
    var isChecked by remember { mutableStateOf(true) }
    val message = if(isChecked) "I'll be there" else "Sorry, I can't be there"

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Switch(
            checked = isChecked,
            onCheckedChange = {
                isChecked = it
            }
        )
        Text(
            text = message,
            fontSize = 30.sp
        )
    }
}